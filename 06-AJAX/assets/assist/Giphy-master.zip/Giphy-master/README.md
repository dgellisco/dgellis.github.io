# Giphy

Utilizes the Giphy API to create a gif search.

Displays knowledge of APIs, HTML, CSS, jQuery, and JavaScript.